import cv2
from skimage.metrics import structural_similarity as ssim

def compare_images(imageA, imageB):
    # 将图片转换为灰度
    grayA = cv2.cvtColor(imageA, cv2.COLOR_BGR2GRAY)
    grayB = cv2.cvtColor(imageB, cv2.COLOR_BGR2GRAY)

    # 计算两个灰度图像之间的结构相似度指数
    score, _ = ssim(grayA, grayB, full=True)
    return score

# 读取图片
image1 = cv2.imread("My_YOLO.jpg")
image2 = cv2.imread("My_YOLO.jpg")

# 比较图片
similarity = compare_images(image1, image2)

print(f"Image similarity: {similarity}")
