import json

__all__ ={'get_data','get_data_large'}
def get_data(file_path):
    with open(file_path, 'r') as f:
        data = json.load(f)
    return data

import json
def get_data_large(file_path):
    # 由于文件中有多行，直接读取会出现错误，因此一行一行读取
    file = open(file_path, 'r', encoding='utf-8')
    papers = []
    for line in file.readlines():
        dic = json.loads(line)
        papers.append(dic)
    return papers
