import cv2
import numpy as np
import torch
from yolov5.utils.general import non_max_suppression, scale_coords
from yolov5.models.experimental import attempt_load
from yolov5.utils.torch_utils import select_device
from scipy.optimize import linear_sum_assignment

# 加载模型
weights = 'yolov5s.pt'  # 模型权重文件路径
device = select_device('')  # 自动选择设备，如果有GPU则使用GPU，否则使用CPU
model = attempt_load(weights, map_location=device)  # 加载模型权重
names = model.names  # 获取类别名称

def bbox_iou(box1, box2):
    """
    计算两个边界框的 IoU。
    box1, box2 - 边界框，格式为 [x1, y1, x2, y2]，其中 (x1, y1) 是左上角坐标，(x2, y2) 是右下角坐标。
    """
    # 计算交集坐标
    inter_x1 = max(box1[0], box2[0])
    inter_y1 = max(box1[1], box2[1])
    inter_x2 = min(box1[2], box2[2])
    inter_y2 = min(box1[3], box2[3])

    # 交集的面积
    inter_area = max(inter_x2 - inter_x1, 0) * max(inter_y2 - inter_y1, 0)

    # 各自框的面积
    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    # 并集的面积
    union_area = box1_area + box2_area - inter_area

    # 计算 IoU
    iou = inter_area / union_area if union_area != 0 else 0

    return iou

def calculate_iou_matrix(res0, res1):
    # 计算两组目标之间的 IoU 矩阵
    iou_matrix = np.zeros((len(res0), len(res1)))
    for i, det0 in enumerate(res0):
        for j, det1 in enumerate(res1):
            iou_matrix[i, j] = bbox_iou(det0, det1)
    return iou_matrix

def match_targets(res0, res1):
    iou_matrix = calculate_iou_matrix(res0, res1)
    row_ind, col_ind = linear_sum_assignment(1 - iou_matrix)  # 使用 1 减去 IoU 作为成本
    return row_ind, col_ind

# 加载图像并进行预处理
img0 = cv2.imread('img0.jpg')  # 加载图像0
img1 = cv2.imread('img1.jpg')  # 加载图像1
img0 = cv2.resize(img0, (640, 480))  # 调整图像大小
img1 = cv2.resize(img1, (640, 480))  # 调整图像大小

# 将BGR图像转换为RGB格式
img0 = cv2.cvtColor(img0, cv2.COLOR_BGR2RGB)
img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)

# 将图像转换为PyTorch张量
img0 = torch.from_numpy(img0.transpose(2, 0, 1)).float()
img1 = torch.from_numpy(img1.transpose(2, 0, 1)).float()

# 正规化图像
img0 /= 255.0
img1 /= 255.0

# 添加batch维度
img0 = img0.unsqueeze(0).to(device)
img1 = img1.unsqueeze(0).to(device)

# 进行目标检测
pred0 = model(img0)[0]  # 对图像0进行目标检测
pred1 = model(img1)[0]  # 对图像1进行目标检测

# 进行非极大值抑制
pred0 = non_max_suppression(pred0, conf_thres=0.5, iou_thres=0.5)
pred1 = non_max_suppression(pred1, conf_thres=0.5, iou_thres=0.5)

# 处理检测结果
for i, det in enumerate(pred0):  # 遍历图像0的检测结果
    if len(det):
        det[:, :4] = scale_coords(img0.shape[2:], det[:, :4], img0.shape[2:]).round()

for i, det in enumerate(pred1):  # 遍历图像1的检测结果
    if len(det):
        det[:, :4] = scale_coords(img1.shape[2:], det[:, :4], img1.shape[2:]).round()

# 如果两个图像都有检测结果，则进行匹配
if len(pred0[0]) > 0 and len(pred1[0]) > 0:
    matched_indices = match_targets(pred0[0][:, :4], pred1[0][:, :4])
    for row, col in zip(*matched_indices):
        print(f"Image 0 object {row} matched with Image 1 object {col}")
