# 我将提供一个完整的代码块，包括模拟函数的定义和使用该函数来生成数据的部分，以确保没有遗漏。

# 重新导入必要的库并重新定义模拟函数和参数

import numpy as np
import matplotlib.pyplot as plt

# 定义模拟数据走势函数
def simulate_trend(start, end, increase, volatility, epochs, peak=None):
    # 生成递增趋势的数据
    trend = np.linspace(start, end, epochs)
    # 添加随机波动性
    noise = np.random.normal(0, volatility, epochs)
    # 确保数据是递增的，在原始的基础上累加，模拟增长趋势
    trend += np.cumsum(np.random.choice([0, increase], epochs) + noise)
    # 如果定义了peak，将趋势限制在peak值以下
    if peak is not None:
        trend = np.clip(trend, start, peak)
    else:
        trend = np.clip(trend, start, None)
    return trend

# 设置epoch的数量
epochs = 300

# 重新定义模拟函数，确保improved-DETR的走势在所有模型中始终最高，但不超过78。

# 设置起始点和结束点
improved_detr_start = 0
improved_detr_end = 78

# 使用模拟函数生成模型的数据走势
# 先生成其他模型的走势，然后确保improved-DETR始终比其他模型高
detr_trend = simulate_trend(start=0, end=60, increase=0.05, volatility=1, epochs=epochs)
yolov8_trend = simulate_trend(start=0, end=67, increase=0.05, volatility=1, epochs=epochs)
fast_rcnn_trend = simulate_trend(start=0, end=62, increase=0.05, volatility=1, epochs=epochs)
mobilenetv3_trend = simulate_trend(start=0, end=60, increase=0.05, volatility=1, epochs=epochs)
vgg16_trend = simulate_trend(start=0, end=63, increase=0.05, volatility=1, epochs=epochs)

# 确保improved-DETR始终比其他模型的趋势线高，但不超过78
max_other_trend = np.max([detr_trend, yolov8_trend, fast_rcnn_trend, mobilenetv3_trend, vgg16_trend], axis=0)
up_detr_trend = np.maximum(max_other_trend + 1, simulate_trend(improved_detr_start, improved_detr_end, 0.1, 1, epochs, peak=78))

# 绘制所有模型的性能曲线
plt.figure(figsize=(12, 6))
plt.plot(detr_trend, label='DETR')
plt.plot(up_detr_trend, label='improved-DETR')  # 不用粗线表示
plt.plot(yolov8_trend, label='YOLOv8')
plt.plot(fast_rcnn_trend, label='Fast-RCNN')
plt.plot(mobilenetv3_trend, label='MobileNetv3')
plt.plot(vgg16_trend, label='VGG-16')

# 添加图例
plt.legend()

# 添加标签和标题
plt.xlabel('Epochs')
plt.ylabel('AP')
plt.title('Simulated Model Performance Comparison with Additional Models')

# 显示图表
plt.show()






