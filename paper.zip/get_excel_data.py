import pandas as pd
__all__ = {'get_data_from_excel'}
def get_data_from_excel(excel_path,dict_name):
    data = pd.read_excel(excel_path)
    # print(yuan_data_exel.to_dict())
    dict_data = list(data.to_dict()[dict_name].values())
    return dict_data
