import pandas as pd
import csv

# 读取CSV文件
def get_data_dict_mAP(path):
    # data_frame = pd.read_csv(path)
    #
    # # 将DataFrame转换为字典
    # data_dict = data_frame.to_dict()
    #
    # print('返回字典数据')
    # return data_dict



    with open(path) as csvfile:
        reader = csv.DictReader(csvfile) # weight 同列的数据
        mAP = [row['     metrics/mAP_0.5'] for row in reader]
    return mAP
def get_data_dict_loss_P(path):
    # data_frame = pd.read_csv(path)
    #
    # # 将DataFrame转换为字典
    # data_dict = data_frame.to_dict()
    #
    # print('返回字典数据')
    # return data_dict



    with open(path) as csvfile:
        reader = csv.DictReader(csvfile) # weight 同列的数据
        data = [[],[],[]]
        for row in reader:
            data[0].append(row['        val/box_loss'])
            data[1].append(row['        val/obj_loss'])
            print(data[1])
            data[2].append(row['   metrics/precision'])
    return data
def get_data_dict_p_r_f1(path):
    # data_frame = pd.read_csv(path)
    #
    # # 将DataFrame转换为字典
    # data_dict = data_frame.to_dict()
    #
    # print('返回字典数据')
    # return data_dict
    with open(path) as csvfile:
        reader = csv.DictReader(csvfile) # weight 同列的数据
        data = [[],[],[]]
        for row in reader:
            data[0].append(row['px'])
            data[1].append(row['py'])
            data[2].append(row['F1'])
    return data