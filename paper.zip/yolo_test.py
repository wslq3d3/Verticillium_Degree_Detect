import matplotlib.pyplot as plt
import numpy as np

# Let's create a similar Precision-Recall curve using dummy data.
# The following data generation strategy will produce curves that look similar in shape to the one provided.

# Assume we have 5 classes to generate Precision-Recall curves for
n_classes = 5
recall_levels = np.linspace(0, 1, 100)

# Generate precision values for each class
precision_values = [np.linspace(1, np.random.rand(), num=100) for _ in range(n_classes)]
precision_values.sort(key=lambda x: x[-1])

# Generate an "all classes" line which is a mean of the individual classes
all_classes_precision = np.mean(precision_values, axis=0)

# Plotting each class curve
colors = ['navy', 'turquoise', 'darkorange', 'cornflowerblue', 'teal']
labels = ['yachong', 'kuhuangwei', 'mirids', 'hongzhihu', 'zhengchang']
for i in range(n_classes):
    plt.plot(recall_levels, precision_values[i], color=colors[i], lw=2,
             label=f'{labels[i]} {precision_values[i][-1]:.3f}')

# Plotting the 'all classes' curve
plt.plot(recall_levels, all_classes_precision, color='blue', linestyle=':', lw=2,
         label=f'all classes {all_classes_precision[-1]:.3f} mAP@0.5')

# Adding labels and title
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall curve')
plt.legend(loc="lower left")

# Show the plot
plt.show()
