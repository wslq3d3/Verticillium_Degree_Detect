import numpy as np
import matplotlib.pyplot as plt

# 5x5 输入图像
input_image = np.array([
    [1, 1, 1, 0, 0],
    [0, 1, 1, 1, 0],
    [0, 0, 1, 1, 1],
    [0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0]
])

# 2x2 卷积核
kernel = np.array([
    [1, 0],
    [0, 1]
])

# 执行卷积操作
output_image = np.zeros((4, 4), dtype=int)  # 输出特征图尺寸为 (4x4)

for i in range(4):
    for j in range(4):
        # 计算卷积操作
        conv = 0
        for m in range(2):
            for n in range(2):
                conv += input_image[i + m, j + n] * kernel[m, n]
        output_image[i, j] = conv

# 显示示意图
fig, axs = plt.subplots(1, 3, figsize=(9, 3))

axs[0].matshow(input_image)
axs[0].set_title('Input Image')
axs[0].axis('off')
for i in range(5):
    for j in range(5):
        axs[0].text(j, i, str(input_image[i, j]), ha='center', va='center', color='red')

axs[1].matshow(kernel)
axs[1].set_title('Convolution Kernel')
axs[1].axis('off')
for i in range(2):
    for j in range(2):
        axs[1].text(j, i, str(kernel[i, j]), ha='center', va='center', color='red')

axs[2].matshow(output_image)
axs[2].set_title('Output Feature Map')
axs[2].axis('off')
for i in range(4):
    for j in range(4):
        axs[2].text(j, i, str(output_image[i, j]), ha='center', va='center', color='red')

plt.tight_layout()
plt.show()
