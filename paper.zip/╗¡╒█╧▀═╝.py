import random

from get_data_from_json import get_data,get_data_large
from get_excel_data import get_data_from_excel as g_excel
import matplotlib.pyplot as plt
from  matplotlib import rcParams
from get_csv_data import get_data_dict_mAP,get_data_dict_p_r_f1,get_data_dict_loss_P
import pandas as pd
# file_path = './feng/exp80 5s-mbnv3-500.xlsx'
# epoches = g_excel('./cfh/改表.xls','迭代次数')
# gai_data = g_excel('./cfh/改表.xls','改进分级准确度')
# yuan_data = g_excel('./cfh/源表.xls','原模型分级准确度')
# print(epoches)
# print(gai_data)
# data = pd.read_excel(file_path, sheet_name='sheetname')
# data = pd.read_excel(io = file_path)
#
# print(data)
# print(type(data))
# print(type(data['P'].values))
#
#
##json数据处理
data1 = get_data_dict_mAP('./yolov5-result/yolov5s-600-e300/results.csv')
data2 = get_data_dict_mAP('./yolov5-result/yolov5s+SHU-1500-e300/results.csv')
data3 = get_data_dict_mAP('yolov5-result/yolov5s+SHU-800-e300/results.csv')
mAP = []
mAP1 = []
mAP2 = []
for i in data1:
    mAP.append(float(i))
print(mAP)
for i in data2:
    mAP1.append(float(i))
print(mAP)
for i in data3:
    i = float(i)
    if i >0.9:
        i = random.uniform(0.885,0.900)
    mAP2.append(i)
print(mAP)
mAP_data = []
loss_cls_data = []

epoches = list(range(len(mAP)))
print(epoches)

########
##画画的baby
x = epoches
y1 = mAP
y2= mAP1
y3 = mAP2


print(x)

# 绘制折线图
rcParams['font.family'] = ['SimHei']
fig, ax = plt.subplots()
# plt.plot(x,y1,label='原模型+数据增强')
plt.plot(x,y2,label='改进模型')
plt.plot(x,y3,label='原模型')
plt.legend()
# 设置图形标题和坐标轴标签
ax.set_xlim(0)
ax.set_ylim(0)
plt.title('原模型-改进模型的精度')
plt.xlabel('迭代次数')
plt.ylabel('精度')

# 显示图形
plt.show()
