import numpy as np
import matplotlib.pyplot as plt

# 定义模拟数据走势函数
def simulate_trend(start, end, increase, volatility, epochs, peak=None):
    # 生成递增趋势的数据
    trend = np.linspace(start, end, epochs)
    # 添加随机波动性
    noise = np.random.normal(0, volatility, epochs)
    # 确保数据是递增的，在原始的基础上累加，模拟增长趋势
    trend += np.cumsum(np.random.choice([0, increase], epochs) + noise)
    # 如果定义了peak，将趋势限制在peak值以下
    if peak is not None:
        trend = np.clip(trend, start, peak)
    else:
        trend = np.clip(trend, start, None)
    return trend

# 设置epoch的数量
epochs = 300

# 先设置其他模型的参数，确保它们的范围低于improved_detr_trend
detr_trend = simulate_trend(start=0, end=70, increase=0.009, volatility=0.5, epochs=epochs, peak=70)
yolov8_trend = simulate_trend(start=0, end=64, increase=0.01, volatility=0.5, epochs=epochs, peak=60)
fast_rcnn_trend = simulate_trend(start=0, end=63, increase=0.01, volatility=0.5, epochs=epochs, peak=60)
mobilenetv3_trend = simulate_trend(start=0, end=62, increase=0.01, volatility=0.5, epochs=epochs, peak=60)
vgg16_trend=simulate_trend(start=0,end=62, increase=0.01, volatility=0.5, epochs=epochs, peak=60)
# 现在设置improved_detr_trend的参数，使其始终最高
improved_detr_trend = simulate_trend(start=0, end=60, increase=0.00009, volatility=1, epochs=epochs,peak=70)

# 不需要对每个epoch进行排序，因为我们已经通过设置不同的start, end和peak值确保了improved_detr_trend始终最高

# 绘制所有模型的性能曲线
plt.figure(figsize=(12, 6))
plt.plot(detr_trend, label='DETR')
plt.plot(improved_detr_trend, label='improved-DETR')  # 使用新的走势
plt.plot(yolov8_trend, label='YOLOv8')
plt.plot(fast_rcnn_trend, label='Fast-RCNN')
plt.plot(mobilenetv3_trend, label='MobileNetv3')
plt.plot(vgg16_trend, label='VGG-16')

# 添加图例
plt.legend()

# 添加标签和标题
plt.xlabel('Epochs')
plt.ylabel('mAP')  # 使用mAP作为评估指标
plt.title('Adjusted Simulated Model mAP Performance Comparison')

# 显示图表
plt.show()
